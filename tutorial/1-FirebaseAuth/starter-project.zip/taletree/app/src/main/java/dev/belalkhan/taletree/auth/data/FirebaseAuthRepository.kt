package dev.belalkhan.taletree.auth.data

import com.google.firebase.auth.FirebaseAuth
import dev.belalkhan.taletree.auth.data.AuthRepository.AuthResult
import javax.inject.Inject

class FirebaseAuthRepository @Inject constructor(
    private val firebaseAuth: FirebaseAuth
) : AuthRepository {

    override suspend fun login(email: String, password: String): AuthResult {
        TODO()
    }
}