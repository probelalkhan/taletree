package dev.belalkhan.taletree.auth.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import dev.belalkhan.taletree.auth.data.AuthRepository.AuthResult
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

class FirebaseAuthRepository @Inject constructor(
    private val firebaseAuth: FirebaseAuth
) : AuthRepository {

    override suspend fun login(email: String, password: String): AuthResult {
        return try {
            val result = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            result?.user?.let { AuthResult.Success(it) }
                ?: AuthResult.Error("Auth Success but user is null")
        } catch (e: Exception) {
            if (e is FirebaseAuthUserCollisionException) {
                try {
                    val result = firebaseAuth.signInWithEmailAndPassword(email, password).await()
                    result?.user?.let { AuthResult.Success(it) }
                        ?: AuthResult.Error("Auth Success but user is null")
                } catch (e: Exception) {
                    AuthResult.Error("Signup Failed: ${e.message}")
                }
            } else {
                AuthResult.Error("Signup Failed: ${e.message}")
            }
        }
    }
}